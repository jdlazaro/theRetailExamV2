﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ATM.Properties;

namespace ATM
{
    class LoggingDecorator : MainDecorator
    {
        
        public LoggingDecorator(Bank bank) : base(bank)
        {

        }


        public  string[] LogValid_TransactionDetails(String transaction, Double amount, Double oldBalance , Double currentBalance)
        {




            string[] array = new string[5];
            array[0] = "Transaction - " + transaction;
            array[1] = "Amount of " + transaction + " " + amount.ToString(); 
            array[2] = "Balance before transaction - " +  oldBalance.ToString();
            array[3] = "Current Balance  " + currentBalance.ToString();
            array[4] = "Date and Time of transaction - " + DateTime.Now.ToShortDateString().ToString() + " " + DateTime.Now.ToShortTimeString().ToString();



            return array;
        }
        


}
}
