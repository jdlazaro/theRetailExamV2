﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATM
{
    class GetBalance : Bank
    {

        private double gb_balance;
         


        public GetBalance()
        {

            this.gb_balance = this.Balance;



        }
        public override void Display()
        {



            Bank._balance = this.gb_balance;

            System.Windows.Forms.MessageBox.Show(Bank._balance.ToString());
            //throw new NotImplementedException();
        }
    }
}
