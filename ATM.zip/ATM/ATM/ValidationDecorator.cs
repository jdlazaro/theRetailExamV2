﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATM
{
     class ValidationDecorator : MainDecorator
    {

        public ValidationDecorator(Bank bank) : base(bank)
        {
                
        }
         
        public  Boolean ValidateWithdrawal(Double amount)
        {


            if (amount > 10000)
            {
                System.Windows.Forms.MessageBox.Show("Unable to process transaction. Maximum withdrawal amount is  10,000");
                return false;
            }

            if (amount > Bank._balance)
            {

                System.Windows.Forms.MessageBox.Show("Unable to process transaction.  Withdrawal amount should not be more than current balance");

                return false;
            }
            else if(amount < 300)
            {

                System.Windows.Forms.MessageBox.Show("Unable to process transaction. Minimum withdrawal amount is 300");

                return false;
            }
            else
            {
                 
                return true;
            }
             
        }







        public Boolean ValidateDeposit(Double amount)
        {


            if (amount > 50000)
            {
                System.Windows.Forms.MessageBox.Show("Unable to process transaction. Maximum deposit amount is  50,000");
                return false;
            }
             if (amount < 1000)
            {

                System.Windows.Forms.MessageBox.Show("Unable to process transaction. Minimum deposit amount is 1000");

                return false;
            }
            else
            {

                return true;
            }

        }












        public override void Display()
        {
             

                base.Display();
            

        }
    }
}
