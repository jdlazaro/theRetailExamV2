﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATM
{
    public abstract class Bank
    {

        public static double _balance = 5000;


        public static Boolean _validationres = false;

        public double Balance
        {

            get
            {
                return _balance;
            }

            set
            {
                _balance = Balance;
            }

        }

         
        public abstract void Display();


    }
}
