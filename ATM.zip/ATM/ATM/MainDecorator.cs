﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATM
{
    abstract class MainDecorator : Bank
    {

        protected Bank _bank;

        public MainDecorator(Bank bank)
        {
            this._bank = bank;
        }


        public override void Display()
        {

            _bank.Display();
             
        }
    }
}
