﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ATM
{
    public partial class Form1 : Form
    {
        public static object Listbox1 { get; internal set; }

        public Form1()
        {
            InitializeComponent(); 
        }

        private void button1_Click(object sender, EventArgs e)
        {

             
            Double gotAmount = Convert.ToDouble(textBox1.Text);

            Double gotOldbalance = Convert.ToDouble(textBox2.Text); 
            Withdrawal transaction = new Withdrawal(gotAmount); 
            ValidationDecorator decorator = new ValidationDecorator(transaction);


            Boolean result = decorator.ValidateWithdrawal(gotAmount);
            if (result == true)
            {
                 

                transaction.Display();

                textBox1.Text = "";
                textBox2.Text = Bank._balance.ToString(); 
                LoggingDecorator print = new LoggingDecorator(transaction);
                // Loop over array by indexes.
                listBox1.Items.Add("***************************");
                listBox1.Items.Add("***************************");

                for (int i = 0; i < print.LogValid_TransactionDetails("Withrawal", gotAmount, gotOldbalance, Bank._balance).Length; i++)
                {

                    listBox1.Items.Add(print.LogValid_TransactionDetails("Withrawal", gotAmount, gotOldbalance, Bank._balance)[i]);

                }
                listBox1.Items.Add("***************************");
                listBox1.Items.Add("***************************");

            }






        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {


            Double gotAmount = Convert.ToDouble(textBox1.Text);

            Double gotOldbalance = Convert.ToDouble(textBox2.Text);

            Deposit transaction = new Deposit(gotAmount); 
            ValidationDecorator decorator = new ValidationDecorator(transaction); 

            Boolean result = decorator.ValidateDeposit(gotAmount);
            if (result == true)
            {

                transaction.Display();

                textBox1.Text = "";
                textBox2.Text = Bank._balance.ToString();
                LoggingDecorator print = new LoggingDecorator(transaction);
                // Loop over array by indexes.
                listBox1.Items.Add("***************************");
                listBox1.Items.Add("***************************");

                for (int i = 0; i < print.LogValid_TransactionDetails("Deposit", gotAmount, gotOldbalance, Bank._balance).Length; i++)
                {

                    listBox1.Items.Add(print.LogValid_TransactionDetails("DEposit", gotAmount, gotOldbalance, Bank._balance)[i]);

                }
                listBox1.Items.Add("***************************");
                listBox1.Items.Add("***************************");


            }








        }

        private void button3_Click(object sender, EventArgs e)
        {
             
            GetBalance gb = new GetBalance();
            gb.Display();

            textBox2.Text=  Bank._balance.ToString();

        }
    }
}
