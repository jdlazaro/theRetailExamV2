﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATM
{
    public class Deposit : Bank
    {

        private double _amount; 
        private double _transactionbalance;



        public Deposit(Double amount)
        {
             
            this._amount = amount;
            this._transactionbalance = this.Balance + amount;



        }

        public override void Display()
        {

            Bank._balance = _transactionbalance;
            System.Windows.Forms.MessageBox.Show("Successful transaction has been completed"); 
 

        }
    }
}
